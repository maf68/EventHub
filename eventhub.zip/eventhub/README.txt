1. Open the parent folder `eventhub` in VS Code
2. Activate the virtual environment by running `\venv\Scripts\activate`
3. Run `cd eventhub`
4. Run `python manage.py makemigrations`
5. Run `python manage.py migrate`
6. Run `python manage.py runserver`