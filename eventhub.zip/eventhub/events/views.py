from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login,authenticate,logout
from .forms import CustomUserCreationForm
from django.http import HttpResponseRedirect
from .models import MyUser



# Create your views here.
def signup(request):
    if request.method == 'POST': 
        form = CustomUserCreationForm(request.POST, request.FILES) # create a form containing data inputted by the user
        if form.is_valid():
            form.save() # create the user and save into database
            print(form.cleaned_data)
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(request, username=username, password=password) #could be password1.
            login(request, user) # login that user
            return redirect('homepage') #take user to homepage
        else:
            return render(request, 'events\signup.html', {'form': form}) #re render html page and display errors
    else:  # if method is a get
         form = CustomUserCreationForm() # create an empty form
         return render(request, 'events\signup.html', { # render the html file with that form 
             'form' : form
         })      

from django.core.files.storage import FileSystemStorage
from django.conf import settings

# def signup(request):
#     if request.method == 'POST': 
#         form = CustomUserCreationForm(request.POST, request.FILES) # add request.FILES to form data
#         if form.is_valid():
#             user = form.save(commit=False)
#             if 'picture' in request.FILES:
#                 picture = request.FILES['picture']
#                 fs = FileSystemStorage()
#                 filename = fs.save(picture.name, picture)
#                 uploaded_file_url = fs.url(filename)
#                 user.picture = uploaded_file_url # set the picture field to the uploaded file URL
#             user.save()
#             username = form.cleaned_data.get('username')
#             password = form.cleaned_data.get('password1')
#             user = authenticate(request, username=username, password=password) #could be password1.
#             login(request, user) # login that user
#             return redirect('homepage') #take user to homepage
#         else:
#             return render(request, 'events\signup.html', {'form': form}) #re render html page and display errors
#     else:  # if method is a get
#          form = CustomUserCreationForm() # create an empty form
#          return render(request, 'events\signup.html', { # render the html file with that form 
#              'form' : form
#          })
    


def login_(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST) #create a form containing data inputted by user
        if form.is_valid():
            username = form.cleaned_data.get('username') #get username and pass in form
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password) #check if username and password in form match database
            if user is not None: #if match
                login(request, user) # login user and redirect to homepage
                return redirect('homepage')
            else:
                error_message = 'Invalid login credentials. Please try again.' # if no match, invalid
        else:
            error_message = 'Invalid login credentials. Please try again.'    # if invalid form, invalid     
    else:
        form = AuthenticationForm() # if get request, create an empty form for user to fill 
        error_message = None
    return render(request, 'events/login.html', {'form': form, 'error_message': error_message}) # render html form     

def logout_(request):
    logout(request)
    return redirect('homepage')

def homepage(request):
    return render(request, 'events/homepage.html', {'user':MyUser})

